from allauth.socialaccount.adapter import DefaultSocialAccountAdapter
from django.contrib.auth import get_user_model
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from .forms import *
from RSP.models import FriendRequest


def main(request):
    return render(request, 'RSP/main.html')


def login(request):
    return render(request, 'RSP/login.html')


def list(request):
    current_user = request.user
    game_list = FriendRequest.objects.filter(to_user=current_user) | FriendRequest.objects.filter(
        from_user=current_user)
    ctx = {"game_list": game_list}
    return render(request, "RSP/list.html", ctx)

def send_friend_request(request):
    if request.method == "POST":
        form = RequestForm(request.POST)
        friend_request = form.save()

        friend_request.from_user = request.user
        friend_request.result = "진행중..."
        friend_request.from_user_num=request.user.id
        friend_request.save()

        return redirect("RSP:list")

    else:
        form = RequestForm()
        ctx = {
            "form": form
        }
        return render(request, "RSP/game.html", ctx)

def rsp_result(u1, u2):
    if u1==u2:
        return "비김"
    elif u1=='가위' and u2=='바위':
        return "패"
    elif u1 == '가위' and u2 == '보':
        return "승"
    elif u1 == '보' and u2 == '바위':
        return "승"
    elif u1 == '보' and u2 == '가위':
        return '패'
    elif u1 == '보' and u2 == '바위':
        return '승'
    elif u1 == '보' and u2 == '가위':
        return '패'

def accept_friend_request(request, pk):
    if request.method=='POST':
        frequest = FriendRequest.objects.get(pk=pk)
        temp = AcceptForm(request.POST).save()

        frequest.to_user_rsp=temp.to_user_rsp
        frequest.save()
        # 결과저장
        frequest.from_user_result = rsp_result(frequest.from_user_rsp, frequest.to_user_rsp)
        frequest.to_user_result = rsp_result(frequest.to_user_rsp, frequest.from_user_rsp)

        temp.delete()
        frequest.save()
        return redirect('RSP:list')
    else:
        form=AcceptForm()
        ctx={
            "form": form
        }
        return render(request, "RSP/accept.html", ctx)

def detail(request, pk):
    pass


class SocialAccountAdapter(DefaultSocialAccountAdapter):

    def save_user(self, request, sociallogin, form=None):
        user = super(SocialAccountAdapter, self).save_user(request, sociallogin, form)

        social_app_name = sociallogin.account.provider.upper()

        if social_app_name == "GOOGLE":
            User.objects.get_or_create_google_user(user_pk=user.pk, extra_data=user.extra_data)
