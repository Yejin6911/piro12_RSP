from django.apps import AppConfig


class RspConfig(AppConfig):
    name = 'RSP'
